import pyautogui
import time
import threading

while True:
    while True: 
        f = pyautogui.locateCenterOnScreen('images/grass.png', confidence=0.8)   
        if f != None:
            print("grass.png Found")
            for counter in range(1,500):
                pyautogui.click(f)
            break
        else:
            print("grass.png Not found, relocating...")
            time.sleep(1)
    
    while True:
        f = pyautogui.locateCenterOnScreen('images/lvlup.png', confidence=0.8)   
        if f != None:
            print("lvlup.png Found")
            for counter in range(1,50):
                pyautogui.click(f)
            break
        else:
            print("lvlup.png Not found, relocating...")
            time.sleep(1)

